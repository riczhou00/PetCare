﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PetCare.Data;
using PetCare.Models;
using System.Net.Http.Json;

namespace PetCare.Controllers
{
    public class ConsultationController : Controller
    {
        private readonly PetCareContext _context;
        private readonly IHttpClientFactory _clientFactory;

        public ConsultationController(PetCareContext context, IHttpClientFactory clientFactory)
        {
            _context = context;
            _clientFactory = clientFactory;
        }

        // GET: Consultation/Create (Antes era Marcar)
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserType") != "Dono")
            {
                return RedirectToAction("Login", "Account");
            }

            int? userId = HttpContext.Session.GetInt32("UserId");
            var animals = _context.Animals.Where(a => a.OwnerId == userId).ToList();
            ViewBag.AnimalId = new SelectList(animals, "AnimalId", "Name");

            return View();
        }

        // POST: Consultation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Consultation consultation, string DateStr, string TimeStr)
        {
            // Processar Data e Hora
            if (DateTime.TryParse($"{DateStr} {TimeStr}", out DateTime finalDate))
            {
                consultation.DateTime = finalDate;
            }
            else
            {
                ModelState.AddModelError("DateTime", "Invalid Date or Time.");
            }

            // Preencher IDs
            int? userId = HttpContext.Session.GetInt32("UserId");
            if (userId.HasValue)
            {
                consultation.OwnerId = userId.Value;
            }

            ModelState.Remove("Animal");
            ModelState.Remove("Owner");
            ModelState.Remove("Veterinarian");
            ModelState.Remove("PerformedProcedures");
            ModelState.Remove("Status");

            // Verificar Erros
            if (!ModelState.IsValid)
            {
                int? uid = HttpContext.Session.GetInt32("UserId");
                var userAnimals = _context.Animals.Where(a => a.OwnerId == uid).ToList();
                ViewBag.AnimalId = new SelectList(userAnimals, "AnimalId", "Name");

                return View(consultation);
            }

            // Enviar API
            try
            {
                consultation.Status = "Pendente";
                var client = _clientFactory.CreateClient("PetCareApi");

                var response = await client.PostAsJsonAsync("api/data/consultation", consultation);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Owner");
                }
                else
                {
                    ModelState.AddModelError("", "Não foi possivel marcar.");
                }
            }
            catch
            {
                ModelState.AddModelError("", "Server connection error.");
            }

            var listAnimals = _context.Animals.Where(a => a.OwnerId == userId).ToList();
            ViewBag.AnimalId = new SelectList(listAnimals, "AnimalId", "Name");
            return View(consultation);
        }

        // GET: Consultation/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var client = _clientFactory.CreateClient("PetCareApi");
                var consultation = await client.GetFromJsonAsync<Consultation>($"api/data/consultation/{id}");

                if (consultation == null) return NotFound();

                return View(consultation);
            }
            catch
            {
                return Content("Error loading consultation details.");
            }
        }
    }
}
