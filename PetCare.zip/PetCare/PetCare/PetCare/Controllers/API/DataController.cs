﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetCare.Data;
using PetCare.Models;

namespace PetCare.Controllers.Api
{

    [Route("api/data")]
    [ApiController]
    public class DataController : ControllerBase
    {
        private readonly PetCareContext _context;

        public DataController(PetCareContext context)
        {
            _context = context;
        }

        // GET: api/dados/animais/dono/1
        [HttpGet("animals/owner/{ownerId}")]
        public IActionResult GetAnimalsByOwner(int ownerId)
        {
            var animals = _context.Animals
                .Where(a => a.OwnerId == ownerId)
                .Include(a => a.Consultations)
                .ToList();

            return Ok(animals);
        }

        // POST: api/dados/consultas
        [HttpPost("consultation")]
        public IActionResult CreateConsultation([FromBody] Consultation consultation)
        {
            if (consultation == null) return BadRequest("Consultation object is null.");

            // Limpeza de segurança (evita ciclos infinitos ou dados inválidos)
            consultation.Animal = null;
            consultation.Owner = null;
            consultation.Veterinarian = null;

            if (string.IsNullOrEmpty(consultation.Status)) consultation.Status = "Pendente";

            consultation.CreatedAt = DateTime.Now;

            try
            {
                _context.Consultations.Add(consultation);
                _context.SaveChanges();
                return Ok(consultation);
            }
            catch (Exception ex)
            {
                var realError = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                return BadRequest($"DB ERROR: {realError}");
            }
        }
        [HttpGet("consultations/simple")]
        public IActionResult GetConsultationsSimple()
        {
            var consultations = _context.Consultations
                // O .Select transforma os dados complexos em dados simples
                .Select(c => new ConsultationListDto
                {
                    ConsultationId = c.ConsultationId,
                    DateTime = c.DateTime,
                    Status = c.Status,
                    Reason = c.Reason,
                    AnimalName = c.Animal.Name,
                    OwnerName = c.Owner.Name,
                    VeterinarianName = c.Veterinarian != null ? c.Veterinarian.Name : "Sem Médico",
                    Procedures = c.PerformedProcedures
                              .Select(pp => pp.VeterinaryProcedure.Name)
                              .ToList()
                })
                .ToList();

            return Ok(consultations);
        }
        
        // GET: api/dados/consultas
        [HttpGet("consultations")]
        public IActionResult GetConsultations()
        {
            var consultations = _context.Consultations
                .AsSplitQuery()
                .Include(c => c.Animal)
                .Include(c => c.Owner)
                .Include(c => c.Veterinarian)
                .Include(c => c.PerformedProcedures)
                    .ThenInclude(pp => pp.VeterinaryProcedure)
                .ToList();

            return Ok(consultations);
        }

        // GET: api/dados/consultas/5
        // (Antes: GetConsulta)
        [HttpGet("consultation/{id}")]
        public IActionResult GetConsultation(int id)
        {
            var consultation = _context.Consultations
                .Include(c => c.Animal)
                .Include(c => c.Owner)
                .Include(c => c.Veterinarian)
                .Include(c => c.PerformedProcedures)
                    .ThenInclude(pp => pp.VeterinaryProcedure)
                .FirstOrDefault(c => c.ConsultationId == id);

            if (consultation == null) return NotFound("Consultation not found.");

            return Ok(consultation);
        }

        // 1. LIST PROCEDURES 
        [HttpGet("procedures")]
        public IActionResult GetProcedures()
        {
            return Ok(_context.VeterinaryProcedures.ToList());
        }

        // 2. CONFIRM CONSULTATION (PUT)
        [HttpPut("consultations/{id}/confirm")]
        public IActionResult ConfirmConsultation(int id, [FromBody] int vetId)
        {
            var consultation = _context.Consultations.Find(id);
            if (consultation == null) return NotFound();

            consultation.Status = "Confirmada";
            consultation.VeterinarianId = vetId;

            _context.SaveChanges();
            return Ok();
        }

        // 3. FINALIZE CONSULTATION (POST)
        [HttpPost("consultations/finalize")]
        public IActionResult FinalizeConsultation([FromBody] FinalizeRequest data)
        {
            var consultation = _context.Consultations.Find(data.ConsultationId);
            if (consultation == null) return NotFound();

            if (data.ProcedureIds != null)
            {
                foreach (var procId in data.ProcedureIds)
                {
                    var performed = new PerformedProcedure
                    {
                        ConsultationId = data.ConsultationId,
                        ProcedureId = procId,
                        Notes = "Realizado"
                    };
                    _context.PerformedProcedures.Add(performed);
                }
            }

            consultation.Notes = data.Notes;
 
            consultation.Status = "Realizada";

            _context.SaveChanges();
            return Ok();
        }

        // GET: api/dados/donos (Para dropdowns)
        [HttpGet("owners")]
        public IActionResult GetOwners()
        {
            var owners = _context.Users
                .Where(u => u.Type == "Dono")
                .Select(u => new
                {
                    u.UserId,
                    u.Name,
                    u.Email,
                    u.Type
                })
                .ToList();

            return Ok(owners);
        }

        [HttpGet("veterinarian")]
        public IActionResult GetVet()
        {
            var veterinarian = _context.Users
                .Where(v => v.Type == "Vet")
                .Select(v => new
                {
                    v.UserId,
                    v.Name,
                    v.Email,
                    v.Type
                })
                .ToList();

            return Ok(veterinarian);
        }

        // CLASSE AUXILIAR (DTO)
        public class FinalizeRequest
        {
            public int ConsultationId { get; set; }
            public string Notes { get; set; }
            public List<int> ProcedureIds { get; set; }
        }


        public class ConsultationListDto
        {
            public int ConsultationId { get; set; }
            public DateTime DateTime { get; set; }
            public string Status { get; set; }
            public string Reason { get; set; }
            public string AnimalName { get; set; }
            public string OwnerName { get; set; }
            public string VeterinarianName { get; set; }
            public List<string> Procedures { get; set; }
        }
    }
}