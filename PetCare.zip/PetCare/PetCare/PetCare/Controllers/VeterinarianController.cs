﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PetCare.Models;
using System.Net.Http.Json;

namespace PetCare.Controllers
{
    public class VeterinarianController : Controller
    {
        private readonly IHttpClientFactory _clientFactory;

        public VeterinarianController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<IActionResult> Index(int? searchAnimalId)
        {
            if (HttpContext.Session.GetString("UserType") != "Vet")
                return RedirectToAction("Login", "Account");

            int? vetId = HttpContext.Session.GetInt32("UserId");
            var client = _clientFactory.CreateClient("PetCareApi");

            var allConsultations = await client.GetFromJsonAsync<List<Consultation>>("api/data/consultations");
            if (allConsultations == null) allConsultations = new List<Consultation>();

            //Pending (Pendentes)
            ViewBag.Pending = allConsultations
                .Where(c => !string.IsNullOrWhiteSpace(c.Status) &&
                            c.Status.Trim().Equals("Pendente", StringComparison.OrdinalIgnoreCase))
                .ToList();

            // History (Histórico - sem status ou antigas)
            var history = allConsultations
                .Where(c => string.IsNullOrWhiteSpace(c.Status) ||
                           (!c.Status.Trim().Equals("Pendente", StringComparison.OrdinalIgnoreCase) &&
                            !c.Status.Trim().Equals("Confirmada", StringComparison.OrdinalIgnoreCase)))
                .OrderByDescending(c => c.DateTime)
                .ToList();

            if (searchAnimalId.HasValue)
            {
                history = history.Where(c => c.AnimalId == searchAnimalId.Value).ToList();
                ViewBag.SearchId = searchAnimalId;
            }
            ViewBag.History = history;

            // Confirmed Schedule
            var mySchedule = allConsultations
                .Where(c => c.VeterinarianId == vetId &&
                            !string.IsNullOrWhiteSpace(c.Status) &&
                            c.Status.Trim().Equals("Confirmada", StringComparison.OrdinalIgnoreCase))
                .OrderBy(c => c.DateTime)
                .ToList();

            return View(mySchedule);
        }

        // CONFIRM
        [HttpGet]
        public async Task<IActionResult> Confirm(int id) 
        {
            int? vetId = HttpContext.Session.GetInt32("UserId");
            var client = _clientFactory.CreateClient("PetCareApi");

            await client.PutAsJsonAsync($"api/data/consultations/{id}/confirm", vetId);

            return RedirectToAction(nameof(Index));
        }

        // PERFORM CONSULTATION (Realizar)
        [HttpGet]
        public async Task<IActionResult> Perform(int id)
        {
            var client = _clientFactory.CreateClient("PetCareApi");
            var consultation = await client.GetFromJsonAsync<Consultation>($"api/data/consultation/{id}");
            var procedures = await client.GetFromJsonAsync<List<VeterinaryProcedure>>("api/data/procedures");

            if (consultation == null) return NotFound();

            var viewModel = new PerformConsultationViewModel
            {
                ConsultationId = consultation.ConsultationId,
                AnimalId = consultation.AnimalId,
                AnimalName = consultation.Animal?.Name ?? "N/A",
                OwnerName = consultation.Owner?.Name ?? "N/A",
                AvailableProcedures = new SelectList(procedures, "ProcedureId", "Name")
            };

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Perform(PerformConsultationViewModel model)
        {
            string finalReport = $"DIAGNÓSTICO: {model.Diagnosis} | NOTAS: {model.Observations}";

            var client = _clientFactory.CreateClient("PetCareApi");
            var apiData = new { ConsultationId = model.ConsultationId, Notes = finalReport, ProcedureIds = model.SelectedProcedureIds };

            var response = await client.PostAsJsonAsync("api/data/consultations/finalize", apiData);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            // Se falhar, recarrega a lista
            var procedures = await client.GetFromJsonAsync<List<VeterinaryProcedure>>("api/data/procedures");
            model.AvailableProcedures = new SelectList(procedures, "ProcedureId", "Name");
            return View(model);
        }

        // DETAILS
        public async Task<IActionResult> Details(int id) 
        {
            var client = _clientFactory.CreateClient("PetCareApi");
            var consultation = await client.GetFromJsonAsync<Consultation>($"api/data/consultations/{id}");
            return View(consultation);
        }
    }
}