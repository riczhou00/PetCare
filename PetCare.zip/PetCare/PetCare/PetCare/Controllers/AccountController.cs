﻿using Microsoft.AspNetCore.Mvc;
using PetCare.Data;
using PetCare.Models;

namespace PetCare.Controllers
{
    public class AccountController : Controller
    {
        private readonly PetCareContext _context;

        public AccountController(PetCareContext context)
        {
            _context = context;
        }

        // GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users
                .FirstOrDefault(u => u.Email == email && u.PasswordHash == password);

            if (user != null)
            {
                // Guardar na Sessão
                HttpContext.Session.SetInt32("UserId", user.UserId);
                HttpContext.Session.SetString("UserName", user.Name);
                HttpContext.Session.SetString("UserType", user.Type);


                // 1. ADMIN
                if (user.Type == "admin" || user.Type == "Admin")
                {
                    return RedirectToAction("Index", "Admin");
                }

                // 2. VETERINÁRIO
                else if (user.Type == "veterinario" || user.Type == "Veterinario" || user.Type == "Vet")
                {
                    return RedirectToAction("Index", "Veterinarian");
                }


                else if (user.Type == "dono" || user.Type == "Dono" || user.Type == "Owner")
                {
                    return RedirectToAction("Index", "Owner");
                }

                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Email ou Password incorretos!";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}