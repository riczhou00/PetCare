﻿using Microsoft.AspNetCore.Mvc;
using PetCare.Models;
using System.Text.Json;

namespace PetCare.Controllers
{
    public class OwnerController : Controller
    {
        private readonly IHttpClientFactory _clientFactory;

        public OwnerController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("UserType") != "Dono")
            {
                return RedirectToAction("Login", "Account");
            }

            int? userId = HttpContext.Session.GetInt32("UserId");
            var client = _clientFactory.CreateClient("PetCareApi");

            var response = await client.GetAsync($"api/data/animals/owner/{userId}");
            List<Animal> animals = new List<Animal>();

            if (response.IsSuccessStatusCode)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles
                };
                animals = JsonSerializer.Deserialize<List<Animal>>(jsonString, options);

                if (animals != null)
                {
                    foreach (var animal in animals)
                    {
                        if (animal.Consultations != null)
                        {
                            foreach (var consultation in animal.Consultations)
                            {
                                consultation.Animal = animal;
                            }
                        }
                    }
                }
            }

            return View(animals);
        }
    }
}