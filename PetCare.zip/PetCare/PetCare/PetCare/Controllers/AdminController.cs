﻿using Microsoft.AspNetCore.Mvc;
using PetCare.Models;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PetCare.Controllers
{
    public class AdminController : Controller
    {
        private readonly IHttpClientFactory _clientFactory;

        public AdminController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<IActionResult> Index(int? year)
        {
            if (HttpContext.Session.GetString("UserType") != "Admin")
            {
                return RedirectToAction("Login", "Account");
            }

            int currentYear = year ?? DateTime.Now.Year;
            var client = _clientFactory.CreateClient("PetCareApi");

            // CONFIGURAÇÃO JSON
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                ReferenceHandler = ReferenceHandler.IgnoreCycles
            };

            // BUSCAR DADOS
            List<Consultation> all = new List<Consultation>();
            try
            {
                all = await client.GetFromJsonAsync<List<Consultation>>("api/data/consultations", options);
            }
            catch
            {
                all = new List<Consultation>();
            }

            if (all == null) all = new List<Consultation>();

            // FILTRAR PELO ANO
            var yearConsultations = all.Where(c => c.DateTime.Year == currentYear).ToList();


            // Trimestres (Quarters)
            int[] quarters = new int[4];
            quarters[0] = yearConsultations.Count(c => c.DateTime.Month <= 3);
            quarters[1] = yearConsultations.Count(c => c.DateTime.Month > 3 && c.DateTime.Month <= 6);
            quarters[2] = yearConsultations.Count(c => c.DateTime.Month > 6 && c.DateTime.Month <= 9);
            quarters[3] = yearConsultations.Count(c => c.DateTime.Month > 9);

            // Top Tratamentos (Treatments)
            var treatmentsStats = yearConsultations
                .SelectMany(c => c.PerformedProcedures ?? new List<PerformedProcedure>())
                .Where(p => p.VeterinaryProcedure != null)
                .GroupBy(p => p.VeterinaryProcedure.Name)
                .Select(g => new { Name = g.Key, Qty = g.Count() })
                .OrderByDescending(x => x.Qty)
                .Take(5)
                .ToList();

            // Top Espécies (Species)
            var speciesStats = yearConsultations
                .GroupBy(c => c.Animal?.Species ?? "Desconhecido")
                .Select(g => new { Name = g.Key, Qty = g.Count() })
                .OrderByDescending(x => x.Qty)
                .Take(5)
                .ToList();

            // PREENCHER MODELO 
            var model = new AdminStatsViewModel
            {
                SelectedYear = currentYear,

                ConsultationsByQuarter = quarters,

                TreatmentNames = treatmentsStats.Select(t => t.Name).ToList(),
                TreatmentQuantities = treatmentsStats.Select(t => t.Qty).ToList(),

                SpeciesNames = speciesStats.Select(e => e.Name).ToList(),
                SpeciesQuantities = speciesStats.Select(e => e.Qty).ToList()
            };

            return View(model);
        }
    }
}