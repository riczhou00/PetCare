﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace PetCare.Models
{
    public class PerformConsultationViewModel
    {
        public int ConsultationId { get; set; }
        public string AnimalName { get; set; }
        public int AnimalId { get; set; }
        public string OwnerName { get; set; }

        // Campos do Formulário (O que o Vet vai preencher)
        public string Diagnosis { get; set; }
        public string Observations { get; set; }

        // Lista de IDs dos tratamentos selecionados (para receber do formulário)
        public List<int> SelectedProcedureIds { get; set; } = new List<int>();

        // Lista de tratamentos disponíveis para encher a "Box" de escolha
        public SelectList AvailableProcedures { get; set; }
    }
}
