﻿using System.ComponentModel.DataAnnotations;

namespace PetCare.Models
{
    public class VeterinaryProcedure
    {
        [Key]
        public int ProcedureId { get; set; }

        public string Name { get; set; }
        public string Type { get; set; }
        public string? Description { get; set; }
    }
}