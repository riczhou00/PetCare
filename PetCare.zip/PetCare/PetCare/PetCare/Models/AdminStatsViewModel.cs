﻿namespace PetCare.Models
{
    public class AdminStatsViewModel
    {
        public int SelectedYear { get; set; }

        // Chart 1: Consultations by Quarter
        public int[] ConsultationsByQuarter { get; set; } 

        // Chart 2: Top Treatments
        public List<string> TreatmentNames { get; set; } 
        public List<int> TreatmentQuantities { get; set; }

        // Chart 3: Top Species
        public List<string> SpeciesNames { get; set; } 
        public List<int> SpeciesQuantities { get; set; }
    }
}
