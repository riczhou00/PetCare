﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PetCare.Models
{
    public class PerformedProcedure
    {
        [Key]
        public int PerformedProcedureId { get; set; }

        public int ConsultationId { get; set; }
        [ForeignKey("ConsultationId")]
        public virtual Consultation? Consultation { get; set; }

        public int ProcedureId { get; set; }
        [ForeignKey("ProcedureId")]
        public virtual VeterinaryProcedure? VeterinaryProcedure { get; set; }

        public string? Notes { get; set; }
    }
}
