﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace PetCare.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string Email { get; set; }

        [JsonIgnore]
        public string PasswordHash { get; set; }

        public string Name { get; set; }
        public string Type { get; set; }
        public string? Phone { get; set; }
        public string? LicenseNumber { get; set; }
        public string? Specialty { get; set; }
        public string? Address { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [InverseProperty("Owner")]
        public virtual ICollection<Animal>? Animals { get; set; }

        [InverseProperty("Veterinarian")]
        public virtual ICollection<Consultation>? ConsultationsAsVet { get; set; }
    }
}