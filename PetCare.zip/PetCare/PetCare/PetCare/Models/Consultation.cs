﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PetCare.Models
{
    public class Consultation
    {
        public int ConsultationId { get; set; }
        public DateTime DateTime { get; set; }
        public string Status { get; set; }
        public string? Notes { get; set; }
        public string? Reason { get; set; }

        public int AnimalId { get; set; }
        [ForeignKey("AnimalId")]
        public virtual Animal? Animal { get; set; }

        public int OwnerId { get; set; }
        [ForeignKey("OwnerId")]
        public virtual User? Owner { get; set; }

        public int? VeterinarianId { get; set; }
        [ForeignKey("VeterinarianId")]
        public virtual User? Veterinarian { get; set; }

        public virtual ICollection<PerformedProcedure>? PerformedProcedures { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
