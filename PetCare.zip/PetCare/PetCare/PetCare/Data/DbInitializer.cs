﻿using PetCare.Models;
using System;
using System.Linq;

namespace PetCare.Data
{
    public static class DbInitializer
    {
        public static void Initialize(PetCareContext context)
        {
            context.Database.EnsureCreated();

            if (context.Users.Any())
            {
                return;
            }
 
            var users = new User[]
            {
                new User { Name = "João Santos", Email = "joao@email.com", PasswordHash = "123", Type = "Dono", Phone = "911111111", Address = "Rua das Flores, 10" },
                
                new User { Name = "Ana Silva", Email = "ana@email.com", PasswordHash = "123", Type = "Dono", Phone = "922222222", Address = "Avenida da Liberdade, 5" },

                new User { Name = "Dr. Pedro", Email = "vet@email.com", PasswordHash = "123", Type = "Vet", LicenseNumber = "VET-999", Specialty = "Geral" },

                new User { Name = "Administrador", Email = "admin@email.com", PasswordHash = "admin", Type = "Admin" }
            };

            context.Users.AddRange(users);
            context.SaveChanges();

            var joao = context.Users.FirstOrDefault(u => u.Email == "joao@email.com");
            var ana = context.Users.FirstOrDefault(u => u.Email == "ana@email.com");

            var animals = new Animal[]
            {
                // Animais do João
                new Animal { Name = "Boby", Species = "Cão", Breed = "Rafeiro", BirthDate = DateTime.Parse("2020-01-01"), Gender = "Macho", OwnerId = joao.UserId },
                new Animal { Name = "Miau", Species = "Gato", Breed = "Siamês", BirthDate = DateTime.Parse("2021-06-15"), Gender = "Fêmea", OwnerId = joao.UserId },

                // Animais da Ana
                new Animal { Name = "Rex", Species = "Cão", Breed = "Pastor Alemão", BirthDate = DateTime.Parse("2019-03-10"), Gender = "Macho", OwnerId = ana.UserId },
                new Animal { Name = "Lulú", Species = "Cão", Breed = "Caniche", BirthDate = DateTime.Parse("2022-01-20"), Gender = "Fêmea", OwnerId = ana.UserId },
                new Animal { Name = "Pipo", Species = "Pássaro", Breed = "Papagaio", BirthDate = DateTime.Parse("2018-12-05"), Gender = "Macho", OwnerId = ana.UserId }
            };

            context.Animals.AddRange(animals);

            var procedures = new VeterinaryProcedure[]
            {
                new VeterinaryProcedure { Name = "Vacina da Raiva", Type = "Vacina", Description = "Vacinação anual obrigatória contra a raiva." },
                new VeterinaryProcedure { Name = "Consulta Geral", Type = "Exame", Description = "Check-up de rotina para avaliação geral." },
                new VeterinaryProcedure { Name = "Análise de Sangue", Type = "Exame", Description = "Hemograma completo e bioquímica." },
                new VeterinaryProcedure { Name = "Raio-X", Type = "Exame", Description = "Radiografia para inspeção óssea ou de órgãos internos." },
                new VeterinaryProcedure { Name = "Esterilização", Type = "Cirurgia", Description = "Procedimento cirúrgico de esterilização." }
            };

            context.VeterinaryProcedures.AddRange(procedures);

            context.SaveChanges();
        }
    }
}
