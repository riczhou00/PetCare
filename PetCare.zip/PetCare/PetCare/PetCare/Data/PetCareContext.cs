﻿using Microsoft.EntityFrameworkCore;
using PetCare.Models;

namespace PetCare.Data
{
    public class PetCareContext : DbContext
    {
        public PetCareContext(DbContextOptions<PetCareContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Animal> Animals { get; set; }
        public DbSet<Consultation> Consultations { get; set; }

        public DbSet<VeterinaryProcedure> VeterinaryProcedures { get; set; }
        public DbSet<PerformedProcedure> PerformedProcedures { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Animal>()
                .HasOne(a => a.Owner)
                .WithMany(u => u.Animals)
                .HasForeignKey(a => a.OwnerId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Consultation>()
                .HasOne(c => c.Owner)
                .WithMany() 
                .HasForeignKey(c => c.OwnerId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Consultation>()
                .HasOne(c => c.Veterinarian)
                .WithMany(u => u.ConsultationsAsVet)
                .HasForeignKey(c => c.VeterinarianId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PerformedProcedure>()
                .HasOne(pp => pp.Consultation)
                .WithMany(c => c.PerformedProcedures)
                .HasForeignKey(pp => pp.ConsultationId);

            modelBuilder.Entity<PerformedProcedure>()
                .HasOne(pp => pp.VeterinaryProcedure)
                .WithMany()
                .HasForeignKey(pp => pp.ProcedureId);
        }
    }
}
